package calcualdora;

public class CelebroMaria_ED {
	
/*Este es el objeto de la clase CerebroCalculadoraED para poder acceder a sus metodos y variables */
	public static CerebroCalculadoraED variableAuxiliar= new CerebroCalculadoraED();
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 2 nº, luego 
	 * calcula el resultado con las variables numero1 y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarSuma(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirDosNumeros();
		variableAuxiliar.resultado=  variableAuxiliar.numero1 + variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}	
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 2 nº, luego 
	 * calcula el resultado con las variables numero1 y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarResta(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirDosNumeros();
		variableAuxiliar.resultado = variableAuxiliar.numero1 - variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 2 nº, luego 
	 * calcula el resultado con las variables numero1 y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarMultiplica(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirDosNumeros();
		variableAuxiliar.resultado = variableAuxiliar.numero1 * variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 2 nº, luego 
	 * calcula el resultado con las variables numero1 y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarDivide(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirDosNumeros();
		variableAuxiliar.resultado = variableAuxiliar.numero1 / variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 1 nº, luego 
	 * calcula el nuevo resultado con las variables resultado y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarSumaRes(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirUnNumero();
		variableAuxiliar.resultado = variableAuxiliar.resultado + variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 1 nº, luego 
	 * calcula el nuevo resultado con las variables resultado y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarRestaRes(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirUnNumero();
		variableAuxiliar.resultado = variableAuxiliar.resultado - variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 1 nº, luego 
	 * calcula el nuevo resultado con las variables resultado y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarMultiplicaRes(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirUnNumero();
		variableAuxiliar.resultado = variableAuxiliar.resultado * variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion, luego llama al metodo de pedir 1 nº, luego 
	 * calcula el nuevo resultado con las variables resultado y numero2, muestra el resultado llamando al metodo correspondiente y por ultimo anade la 
	 * operacion al historial
	 */
	public void operarDivideRes(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.pedirUnNumero();
		variableAuxiliar.resultado = variableAuxiliar.resultado / variableAuxiliar.numero2;
		variableAuxiliar.mostrarResultado(op);
		variableAuxiliar.anadirHistorial(op);
	}
	
	/**
	 * @param Recibe como parametro un objeto del enumerado Operaciones. Primero pide la informacion de la operacion, luego calcula el nuevo
	 * resultado usando el metodo random de la clase Math, despues muestra el resultado por pantalla y por ultimo anade la 
	 * operacion al historial
	 */
	public void numeroAleatorio(Operaciones op) {
		variableAuxiliar.infoOperacion(op);
		variableAuxiliar.resultado = (Math.random()*100+1);
		System.out.println("El número aleatorio generado es: " + variableAuxiliar.resultado + "\n");
		variableAuxiliar.anadirHistorialAleatorio(op);
	}
}