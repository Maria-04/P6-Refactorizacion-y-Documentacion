package calcualdora;

import java.util.Scanner;

public class CalculadoraED {

	public static void main(String[] args) {

		CerebroCalculadoraED cerebroOperaciones = new CerebroCalculadoraED();
		Scanner teclado = new Scanner(System.in);
		String entrada;
		do {
			imprimirCabecera();
			imprimirSeleccionOp();

			entrada = teclado.next();
			if (validarEntrada(entrada)) {
				cerebroOperaciones.procesarOperacion(entrada);
			} else {
				System.out.println("Entrada no reconocida");
			}
		} while (!entrada.equals("x"));
		imprimirDespedida();
	}
	
	/**
	 * Este metodo simplemente tiene un System.out.println que saca por pantalla una cabecera de la calculadora
	 */
	private static void imprimirCabecera() {
		String linea= "\n*----------------------------------*\n";
		System.out.println(linea+"*----------Calculadora ED----------*"+linea);
	}

	/**
	 * Este metodo simplemente tiene un System.out.println que saca por pantalla un mensaje de despedida
	 */
	private static void imprimirDespedida() {
		String linea= "\n*----------------------------------------*\n";
		System.out.println(linea+"*----Gracias por usar Calculadora ED!----*"+linea);
	}

	/**
	 * Este metodo va sacando por pantalla como opcion cada una de las operaciones que podemos hacer y nos indica el comando para terminar el programa
	 */
	private static void imprimirSeleccionOp() {
		Operaciones[] operaciones = Operaciones.values();
		for (Operaciones operacion : operaciones) {
			System.out.println(operacion.getOpcionMenu());
		}
		System.out.println("¿Qué operación desea realizar? (x para terminar)");
	}

	/**
	 * Valida la entrada que se mete por pantalla y dependiendo de lo que hemos metido hace una accion u otra
	 * @param El parametro que recibe el metodo validarEntrada() es una variable de tipo String
	 * @return Devuelve un booleano que, dependiendo de si la entrada que metimos por teclado es una u otra (x,1,5,11...), nos devuelve true o false
	 */
	public static boolean validarEntrada(String entrada) {
		if (entrada.equals("x")) {
			return true;
		} else {
			boolean opValida = false;
			Operaciones[] operaciones = Operaciones.values();
			for (Operaciones operacion : operaciones) {
				if (Integer.toString(operacion.getId()).equals(entrada)) {
					opValida = true;
				}
			}
			return opValida;
		}
	}
}