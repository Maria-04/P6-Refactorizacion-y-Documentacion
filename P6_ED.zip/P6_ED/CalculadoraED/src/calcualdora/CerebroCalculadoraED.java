package calcualdora;

import java.util.Scanner;

public class CerebroCalculadoraED {

/*Estos son los atributos de esta clase */
	public static double resultado;
	public static double numero1;
	public static double numero2;
	public String[] historial;
	public final int TAMANOHISTORIAL = 5;
	public CalculadoraED operacionFinal;
	public CelebroMaria_ED variableNueva= new CelebroMaria_ED() ;
	static Scanner tecladoCce = new Scanner(System.in);

/*Este es el constructor de esta clase, que le da tamano al array de String 'historial' e inicializa la variable resultado a 0 */
	CerebroCalculadoraED() {
		historial = new String[TAMANOHISTORIAL];
		resultado = 0;
	}

	/** Switch: Realiza una operacion u otra dependiendo del valor de su parametro
	 * @param Este metodo recibe como parametro un String y dependiendo de lo que valga el String realiza una accion u otra, si el String no coincide
	 * con ninguno de los casos del switch, realiza la opcion del default y se sale del switch
	 */
	public void procesarOperacion(String op) {
		Operaciones operacion;
		System.out.println("proceso " + op);
		switch (op) {
		case "1":
			operacion = Operaciones.SUMAR;
			variableNueva.operarSuma(operacion);
			break;
		case "2":
			operacion = Operaciones.RESTAR;
			variableNueva.operarResta(operacion);
			break;
		case "3":
			operacion = Operaciones.MULTIPLICAR;
			variableNueva.operarMultiplica(operacion);
			break;
		case "4":
			operacion = Operaciones.DIVIDIR;
			variableNueva.operarDivide(operacion);
			break;
		case "5":
			operacion = Operaciones.SUMAR_RES;
			variableNueva.operarSumaRes(operacion);
			break;
		case "6":
			operacion = Operaciones.RESTAR_RES;
			variableNueva.operarRestaRes(operacion);
			break;
		case "7":
			operacion = Operaciones.MULTIPLICAR_RES;
			variableNueva.operarMultiplicaRes(operacion);
			break;
		case "8":
			operacion = Operaciones.DIVIDIR_RES;
			variableNueva.operarDivideRes(operacion);
			break;
		case "9":
			operacion = Operaciones.RESULTADO;
			mostrarResultadoActual(operacion);
			break;
		case "10":
			operacion = Operaciones.RANDOM;
			variableNueva.numeroAleatorio(operacion);
			break;
		case "11":
			operacion = Operaciones.HISTORIAL;
			operarHistorial(operacion);
			break;
		case "x":
			operacionFinal.validarEntrada(op);
			break;
		default:
			System.out.println("ERROR: La operación " + op + " no es conocida.");
			break;
		}
	}

	/** Metodo que muestra el resultado actual de la operacion que se realizo
	 * @param Recibe como parametro un String, y segun lo que valga, se imprime la informacion de esa operacion y se muestra el resultado por pantalla
	 */
	public void mostrarResultadoActual(Operaciones op) {
		infoOperacion(op);
		System.out.println("El valor actual del resultado es: " + this.resultado + "\n");
	}

	/**Metodo que 'guarda' las ultimas 5 operaciones por si mas adelante se quieren mostrar
	 * @param Recibe como parametro un String, y cuando se acceda al metodo por dicho String se mostrara por pantalla las ultimas 5 operaciones que se
	 * realizaron. Si se realizaron menos de 5 operaciones los valores del historial apareceran como 'null'
	 */
	public void operarHistorial(Operaciones op) {
		System.out.println("*** Historial de las cinco últimas operaciones ***");
		for (String hist : historial) {
			System.out.println(hist);
		}
	}

	/**
	 * @param Recibe por parametro un String,que dependiendo de lo que valga nos muestra por pantalla el nombre y la informacion de una operacion
	 */
	public void infoOperacion(Operaciones op) {
		System.out.println("////////////////////////////// -> " + op.getNombre() + " - " + op.getInfo());
	}

	/**
	 * Este metodo nos pide por pantalla que introduzcamos 1 nº, que se guarda en la variable 'numero2' la variable numero1 hace referencia al 
	 * resultado anterior
	 */
	public static final void pedirUnNumero() {
		System.out.println("Introduce el número: ");
		numero1 = resultado;
		numero2 = tecladoCce.nextDouble();
	}

	/**
	 * Este metodo nos pide por pantalla que introduzcamos 2 numeros, el 1º, se guarda en la variable 'numero1' y el 2º en la vriable 'numero2'
	 */
	public static final void pedirDosNumeros() {
		System.out.println("Introduce el primer número: ");
		numero1 = tecladoCce.nextDouble();
		System.out.println("Introduce el segundo número: ");
		numero2 = tecladoCce.nextDouble();
	}

	/**
	 * @param Recibe por parametro un String,que dependiendo de lo que valga nos muestra el nombre de la operacion en minusculas, nos muestra el 
	 * primer nº, el simbolo de la operacion correspondiente, el 2º nº y el resultado de la operacion
	 */
	public void mostrarResultado(Operaciones op) {
		System.out.println(
				"El resultado de la operación " + op.getNombre().toLowerCase() + " es:" + Double.toString(numero1) + " "
						+ op.getSimbolo() + " " + Double.toString(numero2) + " = " + Double.toString(resultado) + "\n");
	}

	/**
	 * @param Recibe por parametro un String,que dependiendo de lo que valga nos muestra la operacion correspondiente con sus numeros y su simbolo y 
	 * el resultado. Luego asigna la posicion 5 del historial a la 4, la 4 a la 3 ...y asi hasta llegar a la posicion 1 que la asigna a la variable,
	 * que seria una nueva operacion que hagamos
	 */
	public void anadirHistorial(Operaciones op) {
		String nuevaOperacion = op.getNombre() + " -> " + Double.toString(this.numero1) + " " + op.getSimbolo() + " "
				+ Double.toString(this.numero2) + " = " + Double.toString(this.resultado);
		this.historial[4] = this.historial[3];
		this.historial[3] = this.historial[2];
		this.historial[2] = this.historial[1];
		this.historial[1] = this.historial[0];
		this.historial[0] = nuevaOperacion;
	}

	/** Este metodo asigna la posicion 5 del historial a la 4, la 4 a la 3 ...y asi hasta llegar a la posicion 1 que la asigna a la variable,
	 * que seria el numero aleatorio que hemos tenido que generar antes porque si no lo hicimos nos aparecera a ''null'
	 * @param Recibe por parametro un String, que nos muestra el nombre y el resultado de la operacion del numero aleatorio
	 */
	public void anadirHistorialAleatorio(Operaciones op) {
		String nuevaOperacion = op.getNombre() + " -> " + Double.toString(this.resultado);
		this.historial[4] = this.historial[3];
		this.historial[3] = this.historial[2];
		this.historial[2] = this.historial[1];
		this.historial[1] = this.historial[0];
		this.historial[0] = nuevaOperacion;
	}
}