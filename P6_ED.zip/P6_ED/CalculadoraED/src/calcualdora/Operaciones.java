package calcualdora;

public enum Operaciones {
	/* Estas son los elementos y las 'caracteristicas' que los atributos del enumerado tienen*/
	SUMAR("Suma","+","Suma dos números",1),
	RESTAR("Resta","-","Resta dos números",2),
	MULTIPLICAR("Multiplicación","*","Multiplica dos números",3),
	DIVIDIR("División","/","Divide dos números",4),
	SUMAR_RES("Sumar al resultado","+=","Suma un número al resultado actual",5),
	RESTAR_RES("Restar al resultado","-=","Al resultado actual le resta un número",6),
	MULTIPLICAR_RES("Multiplicar al resultado","*=","Multiplica un número al resultado actual",7),
	DIVIDIR_RES("Dividir al resultado","/=","Resultado actual dividido por un número",8),
	RESULTADO("Mostrar resultado","!","Muestra el último resultado",9),
	RANDOM("Número aleatorio","¿?","Crea un número aleatorio 1-100", 10),
	HISTORIAL("Historial","h","Muestra las cinco últimas operaciones",11);
	
	
/*Estos son los atributos que tiene el enumerado */
	private final String NOMBREOPERACION;
	private final String SIMBOLOOPERACION;
	private final String INFOOPERACION;
	private final int IDOPERACION;
	
	/**Este es el constructor del enumerado
	 * @param Como parametros este constructor recibe el nombre, simbolo, informacion e id de los 'atributos' que estan declarados arriba.
	 * En el constructor se declara y se asgina los atributos con los parametros del constructor
	 */
	Operaciones (String nombre, String simbolo, String info, int id){
		this.NOMBREOPERACION = nombre;
		this.SIMBOLOOPERACION = simbolo;
		this.INFOOPERACION = info;
		this.IDOPERACION = id;
	}
	
	/*Estos son los metodos get de los atributos del enumerado */
	/**
	 * @return Devuelve el nombre de la operacion requerida
	 */
	public String getNombre() {return NOMBREOPERACION;}
	/**
	 * @return Devuelve la informacion de la operacion requerida
	 */
	public String getInfo() {return INFOOPERACION;}
	/**
	 * @return Devuelve el simbolo de la operacion requerida
	 */
	public String getSimbolo() {return SIMBOLOOPERACION;}
	/**
	 * @return Devuelve el id de la operacion requerida
	 */
	public int getId() {return IDOPERACION;}
	/**
	 * @return Devuelve el id y el nombre de la operacion requerida
	 */
	public String getOpcionMenu() {return IDOPERACION + ".- " + NOMBREOPERACION;}
	
}